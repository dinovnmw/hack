
export type AppState = 'setup' | 'generating_quiz' | 'taking_quiz' | 'grading' | 'results';

export interface QuizConfig {
  mcqCount: number;
  saqCount: number;
  timeLimit: number;
}

export interface MultipleChoiceQuestion {
  type: 'mcq';
  question: string;
  options: string[];
  correctAnswerIndex: number;
}

export interface ShortAnswerQuestion {
  type: 'saq';
  question: string;
}

export type Question = MultipleChoiceQuestion | ShortAnswerQuestion;

export interface GradedShortAnswer {
    index: number;
    score: number;
    feedback: string;
}

export interface QuizResult {
  mcqResults: { [key: number]: boolean };
  correctMcqCount: number;
  gradedShortAnswers: GradedShortAnswer[];
  userAnswers: { [key: number]: string };
  totalMcq: number;
  totalSaq: number;
}
