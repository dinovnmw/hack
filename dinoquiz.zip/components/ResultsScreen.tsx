
import React from 'react';
import type { QuizResult, Question } from '../types';

interface ResultsScreenProps {
  result: QuizResult;
  questions: Question[];
  onRestart: () => void;
}

const ResultsScreen: React.FC<ResultsScreenProps> = ({ result, questions, onRestart }) => {
  const totalSaqScore = result.gradedShortAnswers.reduce((sum, ans) => sum + ans.score, 0);
  const maxSaqScore = result.totalSaq * 10;
  
  const totalScore = result.correctMcqCount + totalSaqScore;
  const maxScore = result.totalMcq + maxSaqScore;
  
  const percentage = maxScore > 0 ? Math.round((totalScore / maxScore) * 100) : 0;

  const getScoreColor = (p: number) => {
    if (p >= 80) return 'text-green-500 dark:text-green-400';
    if (p >= 50) return 'text-yellow-500 dark:text-yellow-400';
    return 'text-red-500 dark:text-red-400';
  };

  return (
    <div className="space-y-8">
      <div className="text-center p-6 bg-slate-100 dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700">
        <h2 className="text-3xl font-bold text-slate-800 dark:text-white">Quiz Results</h2>
        <p className={`text-6xl font-bold my-4 ${getScoreColor(percentage)}`}>{percentage}%</p>
        <p className="text-slate-600 dark:text-slate-300 text-lg">
          Total Score: {totalScore} / {maxScore}
        </p>
        <div className="flex justify-center gap-8 mt-4 text-slate-500 dark:text-slate-400">
          <span>MCQs: {result.correctMcqCount} / {result.totalMcq}</span>
          <span>Short Answers: {totalSaqScore} / {maxSaqScore}</span>
        </div>
      </div>

      <div className="space-y-4">
        {questions.map((question, index) => {
          const userAnswer = result.userAnswers[index];
          
          if (question.type === 'mcq') {
            const isCorrect = result.mcqResults[index];
            const userOptionIndex = userAnswer !== undefined ? parseInt(userAnswer) : -1;
            return (
              <div key={index} className={`p-4 rounded-lg border ${isCorrect ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
                <p className="font-semibold text-slate-700 dark:text-slate-200 mb-2">{index + 1}. {question.question}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">Your answer: <span className="font-medium text-slate-700 dark:text-slate-200">{userOptionIndex !== -1 ? question.options[userOptionIndex] : 'Not answered'}</span></p>
                {!isCorrect && <p className="text-sm text-green-600 dark:text-green-400">Correct answer: <span className="font-medium">{question.options[question.correctAnswerIndex]}</span></p>}
              </div>
            );
          }

          if (question.type === 'saq') {
            const gradedAnswer = result.gradedShortAnswers.find(sa => sa.index === index);
            return (
              <div key={index} className="p-4 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <p className="font-semibold text-slate-700 dark:text-slate-200 mb-2">{index + 1}. {question.question}</p>
                <p className="text-sm text-slate-500 dark:text-slate-400 italic mb-3 p-3 bg-slate-200/50 dark:bg-slate-700/50 rounded-md">Your answer: "{userAnswer || 'Not answered'}"</p>
                {gradedAnswer ? (
                  <div className="bg-purple-500/10 border border-purple-500/30 p-3 rounded-md">
                    <p className="font-semibold text-purple-600 dark:text-purple-300">AI Feedback (Score: {gradedAnswer.score}/10)</p>
                    <p className="text-slate-600 dark:text-slate-300 text-sm mt-1">{gradedAnswer.feedback}</p>
                  </div>
                ) : (
                  <p className="text-yellow-600 dark:text-yellow-500 text-sm">This answer was not graded.</p>
                )}
              </div>
            );
          }
          return null;
        })}
      </div>

      <button
        onClick={onRestart}
        className="w-full py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 dark:focus:ring-offset-slate-900 focus:ring-purple-500 transition-all transform hover:scale-105"
      >
        Create Another Quiz
      </button>
    </div>
  );
};

export default ResultsScreen;
