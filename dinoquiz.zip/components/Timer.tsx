
import React, { useState, useEffect } from 'react';

interface TimerProps {
  minutes: number;
  onTimeUp: () => void;
}

const Timer: React.FC<TimerProps> = ({ minutes, onTimeUp }) => {
  const [seconds, setSeconds] = useState(minutes * 60);

  useEffect(() => {
    if (seconds <= 0) {
      onTimeUp();
      return;
    }
    const interval = setInterval(() => {
      setSeconds(prev => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [seconds, onTimeUp]);

  const displayMinutes = Math.floor(seconds / 60);
  const displaySeconds = seconds % 60;

  const timeColorClass = seconds < 60 ? 'text-red-500 dark:text-red-400' : 'text-slate-700 dark:text-slate-200';

  return (
    <div className={`text-xl font-mono p-2 rounded-lg bg-slate-200/50 dark:bg-slate-700/50 ${timeColorClass}`}>
      <span>{String(displayMinutes).padStart(2, '0')}</span>
      <span>:</span>
      <span>{String(displaySeconds).padStart(2, '0')}</span>
    </div>
  );
};

export default Timer;
