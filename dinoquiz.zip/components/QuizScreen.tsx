
import React, { useState, useCallback, useEffect } from 'react';
import type { Question } from '../types';
import Timer from './Timer';
import { getHint } from '../services/geminiService';
import Loader from './Loader';

interface QuizScreenProps {
  questions: Question[];
  timeLimit: number;
  documentText: string;
  onSubmit: (answers: Record<number, string>) => void;
}

const QuizScreen: React.FC<QuizScreenProps> = ({ questions, timeLimit, documentText, onSubmit }) => {
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const [timeOnQuestion, setTimeOnQuestion] = useState(0);
  const [showHintButton, setShowHintButton] = useState(false);
  const [hints, setHints] = useState<Record<number, string>>({});
  const [isHintLoading, setIsHintLoading] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];

  useEffect(() => {
    // Reset timer and button when question changes
    setTimeOnQuestion(0);
    setShowHintButton(false);

    // Set up interval to track time on the current question
    const timer = setInterval(() => {
        setTimeOnQuestion(prev => prev + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [currentQuestionIndex]);

  useEffect(() => {
    // Show the hint button after 2 minutes (120 seconds) if no hint exists
    if (timeOnQuestion >= 120 && !hints[currentQuestionIndex] && !isHintLoading) {
        setShowHintButton(true);
    }
  }, [timeOnQuestion, hints, currentQuestionIndex, isHintLoading]);

  const handleAnswerChange = (questionIndex: number, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionIndex]: answer }));
  };
  
  const handleSubmit = useCallback(() => {
    onSubmit(answers);
  }, [answers, onSubmit]);

  const handleGetHint = async () => {
    if (isHintLoading || hints[currentQuestionIndex]) return;
    setIsHintLoading(true);
    setShowHintButton(false);
    try {
        const hintText = await getHint(documentText, currentQuestion);
        setHints(prev => ({ ...prev, [currentQuestionIndex]: hintText }));
    } catch (error) {
        console.error("Failed to get hint:", error);
        setHints(prev => ({ ...prev, [currentQuestionIndex]: "Sorry, I couldn't generate a hint right now." }));
    } finally {
        setIsHintLoading(false);
    }
  };

  return (
    <div>
        <div className="sticky top-0 bg-white/80 dark:bg-slate-800/80 backdrop-blur-md py-4 px-6 mb-6 rounded-lg border border-slate-200 dark:border-slate-700 flex justify-between items-center z-10">
            <h2 className="text-2xl font-bold text-slate-800 dark:text-white">Quiz in Progress</h2>
            <Timer minutes={timeLimit} onTimeUp={handleSubmit} />
        </div>

        <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
                    Question {currentQuestionIndex + 1} of {questions.length}
                </span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5">
                <div 
                    className="bg-purple-600 h-2.5 rounded-full transition-all duration-500" 
                    style={{ width: `${((currentQuestionIndex + 1) / questions.length) * 100}%` }}>
                </div>
            </div>
        </div>
      
        <div className="bg-slate-100 dark:bg-slate-800 p-6 rounded-lg border border-slate-200 dark:border-slate-700 mb-6">
            <h3 className="text-lg font-semibold text-purple-600 dark:text-purple-300 mb-4">{`Question ${currentQuestionIndex + 1}`}</h3>
            <p className="text-slate-700 dark:text-slate-200 mb-4">{currentQuestion.question}</p>
            {currentQuestion.type === 'mcq' && (
                <div className="space-y-3">
                    {currentQuestion.options.map((option, optionIndex) => (
                    <label key={optionIndex} className={`flex items-center p-3 rounded-md border-2 transition-colors cursor-pointer ${answers[currentQuestionIndex] === String(optionIndex) ? 'bg-purple-500/20 dark:bg-purple-500/30 border-purple-500' : 'bg-slate-200/50 dark:bg-slate-700/50 border-slate-300 dark:border-slate-600 hover:border-slate-400 dark:hover:border-slate-500'}`}>
                        <input
                        type="radio"
                        name={`question-${currentQuestionIndex}`}
                        value={optionIndex}
                        checked={answers[currentQuestionIndex] === String(optionIndex)}
                        onChange={(e) => handleAnswerChange(currentQuestionIndex, e.target.value)}
                        className="form-radio h-5 w-5 text-purple-600 bg-slate-300 dark:bg-slate-600 border-slate-400 dark:border-slate-500 focus:ring-purple-500"
                        />
                        <span className="ml-3 text-slate-700 dark:text-slate-300">{option}</span>
                    </label>
                    ))}
                </div>
            )}
            {currentQuestion.type === 'saq' && (
                <textarea
                    value={answers[currentQuestionIndex] || ''}
                    onChange={(e) => handleAnswerChange(currentQuestionIndex, e.target.value)}
                    rows={4}
                    className="w-full bg-slate-200/50 dark:bg-slate-700/50 border-slate-300 dark:border-slate-600 rounded-md p-3 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Your answer..."
                />
            )}
        </div>

        { (showHintButton || isHintLoading || hints[currentQuestionIndex]) &&
            <div className="mb-6">
                { showHintButton &&
                    <button onClick={handleGetHint} className="w-full text-center py-2 px-4 rounded-lg bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-700 dark:text-yellow-300 font-medium transition-colors">
                        Stuck? Get an AI Hint
                    </button>
                }
                { isHintLoading && <Loader message="AI is generating a hint..." /> }
                { hints[currentQuestionIndex] &&
                    <div className="p-4 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
                        <p className="font-semibold text-indigo-600 dark:text-indigo-300">💡 AI Hint</p>
                        <p className="text-sm text-indigo-700 dark:text-indigo-300/80 mt-1">{hints[currentQuestionIndex]}</p>
                    </div>
                }
            </div>
        }

        <div className="flex justify-between mt-4">
            <button
                onClick={() => setCurrentQuestionIndex(i => i - 1)}
                disabled={currentQuestionIndex === 0}
                className="py-2 px-6 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-slate-500 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 dark:focus:ring-offset-slate-900 focus:ring-slate-500 disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:cursor-not-allowed disabled:text-slate-500 dark:disabled:text-slate-400"
            >
                Previous
            </button>
            {currentQuestionIndex < questions.length - 1 ? (
                <button
                    onClick={() => setCurrentQuestionIndex(i => i + 1)}
                    className="py-2 px-8 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 dark:focus:ring-offset-slate-900 focus:ring-purple-500"
                >
                    Next
                </button>
            ) : (
                <button
                    onClick={handleSubmit}
                    className="py-2 px-8 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 dark:focus:ring-offset-slate-900 focus:ring-green-500"
                >
                    Submit Quiz
                </button>
            )}
        </div>
    </div>
  );
};

export default QuizScreen;
