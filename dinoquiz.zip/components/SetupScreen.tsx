
import React, { useState, useRef } from 'react';
import type { QuizConfig } from '../types';

interface SetupScreenProps {
  onStart: (file: File, config: QuizConfig) => void;
  error: string | null;
}

const FileUploadIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-slate-400 dark:text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
    </svg>
);

const SetupScreen: React.FC<SetupScreenProps> = ({ onStart, error }) => {
  const [file, setFile] = useState<File | null>(null);
  const [mcqCount, setMcqCount] = useState(5);
  const [saqCount, setSaqCount] = useState(2);
  const [timeLimit, setTimeLimit] = useState(10);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (file) {
      onStart(file, { mcqCount, saqCount, timeLimit });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };
  
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {error && <div className="bg-red-500/20 border border-red-500 text-red-400 dark:text-red-300 p-3 rounded-lg text-center">{error}</div>}

      <div>
        <label className="block text-lg font-medium text-slate-700 dark:text-slate-300 mb-2">1. Upload Document</label>
        <div 
          className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 dark:border-slate-600 border-dashed rounded-md cursor-pointer hover:border-purple-400 transition-colors"
          onClick={() => fileInputRef.current?.click()}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <div className="space-y-1 text-center py-4">
            <FileUploadIcon />
            <div className="flex text-sm text-slate-600 dark:text-slate-400">
              <p className="pl-1">
                {file ? `${file.name}` : 'Drag & drop a file, or click to upload'}
              </p>
            </div>
             <p className="text-xs text-slate-500 dark:text-slate-500">PDF, DOC, DOCX up to 10MB</p>
          </div>
          <input ref={fileInputRef} id="file-upload" name="file-upload" type="file" className="sr-only" accept=".pdf,.docx,.doc" onChange={handleFileChange} />
        </div>
      </div>
      
      <div>
        <label className="block text-lg font-medium text-slate-700 dark:text-slate-300 mb-2">2. Configure Quiz</label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <NumberInput label="Multiple Choice" value={mcqCount} onChange={setMcqCount} />
          <NumberInput label="Short Answer" value={saqCount} onChange={setSaqCount} />
          <NumberInput label="Time Limit (Mins)" value={timeLimit} onChange={setTimeLimit} />
        </div>
      </div>

      <button
        type="submit"
        disabled={!file}
        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-100 dark:focus:ring-offset-slate-900 focus:ring-purple-500 disabled:bg-slate-300 dark:disabled:bg-slate-700 disabled:cursor-not-allowed disabled:text-slate-500 dark:disabled:text-slate-400 transition-all transform hover:scale-105"
      >
        Generate Quiz
      </button>
    </form>
  );
};

interface NumberInputProps {
    label: string;
    value: number;
    onChange: (value: number) => void;
}

const NumberInput: React.FC<NumberInputProps> = ({ label, value, onChange }) => (
    <div>
        <label htmlFor={label} className="block text-sm font-medium text-slate-500 dark:text-slate-400">{label}</label>
        <input
            type="number"
            id={label}
            min="0"
            max="20"
            value={value}
            onChange={(e) => onChange(parseInt(e.target.value, 10) || 0)}
            className="mt-1 block w-full bg-slate-100 dark:bg-slate-700 border-slate-300 dark:border-slate-600 rounded-md shadow-sm py-2 px-3 text-slate-800 dark:text-white focus:outline-none focus:ring-purple-500 focus:border-purple-500 sm:text-sm"
        />
    </div>
);

export default SetupScreen;
