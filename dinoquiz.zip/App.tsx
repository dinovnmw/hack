import React, { useState, useCallback, useEffect } from 'react';
import { AppState, QuizConfig, Question, QuizResult } from './types';
import SetupScreen from './components/SetupScreen';
import QuizScreen from './components/QuizScreen';
import ResultsScreen from './components/ResultsScreen';
import Loader from './components/Loader';
import { readFileContent } from './services/fileReader';
import { generateQuiz, gradeShortAnswers } from './services/geminiService';

const ThemeToggle = ({ theme, toggleTheme }: { theme: string; toggleTheme: () => void }) => (
    <button
        onClick={toggleTheme}
        className="absolute top-4 right-4 p-2 rounded-full bg-slate-700/50 dark:bg-slate-800/50 text-yellow-300 dark:text-purple-300 focus:outline-none focus:ring-2 focus:ring-purple-500"
        aria-label="Toggle theme"
    >
        {theme === 'dark' ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
        ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
            </svg>
        )}
    </button>
);


function App() {
  const [appState, setAppState] = useState<AppState>('setup');
  const [error, setError] = useState<string | null>(null);
  const [quizConfig, setQuizConfig] = useState<QuizConfig | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [quizResult, setQuizResult] = useState<QuizResult | null>(null);
  const [documentText, setDocumentText] = useState<string>('');
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light' || savedTheme === 'dark') {
      return savedTheme;
    }
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) {
      return 'light';
    }
    return 'dark'; // Default theme
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleQuizStart = useCallback(async (file: File, config: QuizConfig) => {
    setAppState('generating_quiz');
    setError(null);
    setQuizConfig(config);

    try {
      const text = await readFileContent(file);
      setDocumentText(text);

      if (!text || text.trim().length < 50) {
        throw new Error("Could not extract enough text from the file. Please try another file.");
      }
      
      const generatedQuestions = await generateQuiz(text, config.mcqCount, config.saqCount);
      setQuestions(generatedQuestions);
      setAppState('taking_quiz');
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : "An unknown error occurred during quiz generation.";
      setError(errorMessage);
      setAppState('setup');
    }
  }, []);

  const handleQuizSubmit = useCallback(async (answers: Record<number, string>) => {
    setAppState('grading');
    setError(null);

    const mcqResults: { [key: number]: boolean } = {};
    let correctMcqCount = 0;
    const shortAnswerSubmissions: { question: string; answer: string; index: number }[] = [];

    questions.forEach((q, index) => {
      if (q.type === 'mcq') {
        const isCorrect = parseInt(answers[index]) === q.correctAnswerIndex;
        mcqResults[index] = isCorrect;
        if (isCorrect) correctMcqCount++;
      } else if (q.type === 'saq' && answers[index]) {
        shortAnswerSubmissions.push({ question: q.question, answer: answers[index], index });
      }
    });

    let gradedShortAnswers: { index: number; score: number; feedback: string }[] = [];
    if (shortAnswerSubmissions.length > 0) {
      try {
        gradedShortAnswers = await gradeShortAnswers(documentText, shortAnswerSubmissions);
      } catch (err) {
        console.error("Failed to grade short answers:", err);
        setError("There was an error grading the short answer questions. They will be marked as 0.");
      }
    }

    setQuizResult({
      mcqResults,
      correctMcqCount,
      gradedShortAnswers,
      userAnswers: answers,
      totalMcq: questions.filter(q => q.type === 'mcq').length,
      totalSaq: questions.filter(q => q.type === 'saq').length,
    });
    setAppState('results');
  }, [questions, documentText]);

  const handleRestart = () => {
    setAppState('setup');
    setError(null);
    setQuizConfig(null);
    setQuestions([]);
    setQuizResult(null);
    setDocumentText('');
  };

  const renderContent = () => {
    switch (appState) {
      case 'generating_quiz':
        return <Loader message="Generating your quiz... This may take a moment." />;
      case 'grading':
        return <Loader message="Grading your answers... The AI is thinking." />;
      case 'taking_quiz':
        return quizConfig && questions.length > 0 ? (
          <QuizScreen questions={questions} timeLimit={quizConfig.timeLimit} documentText={documentText} onSubmit={handleQuizSubmit} />
        ) : (
          <Loader message="Loading quiz..." />
        );
      case 'results':
        return quizResult && <ResultsScreen result={quizResult} questions={questions} onRestart={handleRestart} />;
      case 'setup':
      default:
        return <SetupScreen onStart={handleQuizStart} error={error} />;
    }
  };

  return (
    <div className="bg-slate-100 dark:bg-slate-900 text-slate-800 dark:text-white min-h-screen font-sans flex flex-col items-center justify-center p-4 transition-colors duration-300">
      <ThemeToggle theme={theme} toggleTheme={toggleTheme} />
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-500 to-indigo-600 dark:from-purple-400 dark:to-indigo-500 text-transparent bg-clip-text">
            🦖 DinoQuiz
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2">Unearth knowledge from your documents.</p>
        </header>
        <main className="bg-white/80 dark:bg-slate-800/50 backdrop-blur-sm rounded-2xl shadow-2xl shadow-purple-500/10 p-6 md:p-8 border border-slate-200 dark:border-slate-700">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}

export default App;