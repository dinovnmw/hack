// These are available globally from the scripts in index.html
declare const pdfjsLib: any;
declare const mammoth: any;

export const readFileContent = async (file: File): Promise<string> => {
  const extension = file.name.split('.').pop()?.toLowerCase();

  if (extension === 'pdf') {
    return readPdfFile(file);
  } else if (extension === 'docx' || extension === 'doc') {
    return readDocxFile(file);
  } else {
    throw new Error('Unsupported file type. Please upload a PDF or DOCX/DOC file.');
  }
};

const readPdfFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (event) => {
      if (!event.target?.result) {
        return reject(new Error('Failed to read PDF file.'));
      }
      try {
        const pdf = await pdfjsLib.getDocument(event.target.result).promise;
        let content = '';
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const textContent = await page.getTextContent();
          content += textContent.items.map((item: any) => item.str).join(' ');
        }
        resolve(content);
      } catch (error) {
        console.error("Error parsing PDF: ", error);
        reject(new Error('Could not parse the PDF file. It might be corrupted or protected.'));
      }
    };
    reader.onerror = () => reject(new Error('Error reading file.'));
    reader.readAsArrayBuffer(file);
  });
};

const readDocxFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      if (!event.target?.result) {
        return reject(new Error('Failed to read DOCX file.'));
      }
      mammoth.extractRawText({ arrayBuffer: event.target.result })
        .then((result: any) => {
          resolve(result.value);
        })
        .catch((error: any) => {
          console.error("Error parsing Word file: ", error);
          reject(new Error('Could not parse the Word file. Legacy .doc formats (Word 97-2003) are not supported. Please save the file as .docx and try again.'));
        });
    };
    reader.onerror = () => reject(new Error('Error reading file.'));
    reader.readAsArrayBuffer(file);
  });
};