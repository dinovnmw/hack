
import { GoogleGenAI, Type } from "@google/genai";
import type { Question } from '../types';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Using a placeholder. This will fail unless the environment provides it.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "YOUR_API_KEY_HERE" });

const quizGenerationSchema = {
    type: Type.OBJECT,
    properties: {
        questions: {
            type: Type.ARRAY,
            description: "An array of quiz questions.",
            items: {
                type: Type.OBJECT,
                properties: {
                    type: {
                        type: Type.STRING,
                        description: "The type of question, either 'mcq' for multiple-choice or 'saq' for short-answer.",
                        enum: ['mcq', 'saq'],
                    },
                    question: {
                        type: Type.STRING,
                        description: "The question text."
                    },
                    options: {
                        type: Type.ARRAY,
                        description: "For 'mcq' type, an array of 4 possible answer strings.",
                        items: { type: Type.STRING }
                    },
                    correctAnswerIndex: {
                        type: Type.INTEGER,
                        description: "For 'mcq' type, the 0-based index of the correct answer in the 'options' array."
                    }
                },
                required: ['type', 'question'],
            }
        }
    },
    required: ['questions'],
};


export const generateQuiz = async (
    documentText: string,
    mcqCount: number,
    saqCount: number
): Promise<Question[]> => {
    const prompt = `
    Based on the following document text, please generate a quiz.
    The quiz should contain exactly ${mcqCount} multiple-choice questions and ${saqCount} short-answer questions.
    For multiple-choice questions, provide 4 distinct options and identify the correct one.
    The questions should be relevant and cover different aspects of the provided text.

    DOCUMENT TEXT:
    ---
    ${documentText.substring(0, 30000)}
    ---
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: quizGenerationSchema,
                temperature: 0.7,
            },
        });

        const jsonText = response.text.trim();
        const parsedResponse = JSON.parse(jsonText);
        
        if (!parsedResponse.questions || !Array.isArray(parsedResponse.questions)) {
            throw new Error("Invalid format received from AI for quiz questions.");
        }

        return parsedResponse.questions as Question[];
    } catch (error) {
        console.error("Error generating quiz:", error);
        throw new Error("Failed to generate quiz from the document. The AI may be experiencing issues or the document content is not suitable.");
    }
};

const gradingSchema = {
    type: Type.OBJECT,
    properties: {
        evaluations: {
            type: Type.ARRAY,
            description: "An array of evaluations for the short answer questions.",
            items: {
                type: Type.OBJECT,
                properties: {
                    index: {
                        type: Type.INTEGER,
                        description: "The original index of the question being graded."
                    },
                    score: {
                        type: Type.INTEGER,
                        description: "A score from 0 to 10, where 10 is a perfect answer."
                    },
                    feedback: {
                        type: Type.STRING,
                        description: "A brief justification for the score, explaining why the answer is correct, partially correct, or incorrect, based on the context."
                    }
                },
                required: ['index', 'score', 'feedback'],
            }
        }
    },
    required: ['evaluations']
};

export const gradeShortAnswers = async (
    documentText: string,
    submissions: { question: string; answer: string; index: number }[]
): Promise<{ index: number; score: number; feedback: string }[]> => {
    const prompt = `
    You are an expert teaching assistant. Your task is to grade the following short-answer questions based on the provided document context.
    For each answer, provide a score from 0 to 10 and a brief feedback explaining the score.
    A score of 10 means the answer is comprehensive and accurate according to the text.
    A score of 0 means the answer is completely incorrect or irrelevant.
    Partial scores should reflect the degree of correctness.

    DOCUMENT CONTEXT:
    ---
    ${documentText.substring(0, 28000)}
    ---

    QUESTIONS AND USER ANSWERS TO GRADE:
    ---
    ${JSON.stringify(submissions, null, 2)}
    ---
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: gradingSchema,
                temperature: 0.3,
            },
        });

        const jsonText = response.text.trim();
        const parsedResponse = JSON.parse(jsonText);

        if (!parsedResponse.evaluations || !Array.isArray(parsedResponse.evaluations)) {
            throw new Error("Invalid format received from AI for grading.");
        }
        
        return parsedResponse.evaluations;
    } catch (error) {
        console.error("Error grading short answers:", error);
        throw new Error("Failed to grade short answers. The AI may be experiencing issues.");
    }
};

export const getHint = async (
    documentText: string,
    question: Question
): Promise<string> => {
    const prompt = `
    Based on the following document text, provide a helpful hint for the user trying to answer the question below.
    Do not give away the direct answer. Instead, guide the user by explaining the relevant concepts or pointing them to the right part of the text to think about.
    The hint should be concise and encouraging.

    DOCUMENT TEXT:
    ---
    ${documentText.substring(0, 28000)}
    ---

    QUESTION:
    "${question.question}"
    ${question.type === 'mcq' ? `\nOptions:\n- ${question.options.join('\n- ')}` : ''}
    ---
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.8,
            },
        });
        return response.text;
    } catch (error) {
        console.error("Error generating hint:", error);
        throw new Error("Failed to generate a hint from the AI.");
    }
};
